﻿using HealthInsuranceManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HealthInsuranceManagementSystem.Controllers
{
    public class EmployeeController : Controller
    {
        private ApplicationDbContext dbContext = new ApplicationDbContext();
        public ActionResult Index(string search = "", string SortColumn = "EmpNo", 
            string IconClass = "fa-solid fa-sort-down")
        {
            List<Employee> employees = dbContext.Employees
                .Where(employee => employee.FirstName.Contains(search)).ToList();

            ViewBag.Search = search;
            ViewBag.SortColumn = SortColumn;
            ViewBag.IconClass = IconClass;

            switch (SortColumn)
            {
                case "EmpNo":
                    switch (IconClass)
                    {
                        case "fa-solid fa-sort-down":
                            employees.OrderBy(emp => emp.EmpNo);
                            break;
                        case "fa-solid fa-sort-up":
                            employees.OrderByDescending(emp => emp.EmpNo);
                            break;
                    }
                    break;
                case "Designation":
                    switch (IconClass)
                    {
                        case "fa-solid fa-sort-down":
                            employees.OrderBy(emp => emp.Designation);
                            break;
                        case "fa-solid fa-sort-up":
                            employees.OrderByDescending(emp => emp.Designation);
                            break;
                    }
                    break;
                case "Salary":
                    switch (IconClass)
                    {
                        case "fa-solid fa-sort-down":
                            employees.OrderBy(emp => emp.Salary);
                            break;
                        case "fa-solid fa-sort-up":
                            employees.OrderByDescending(emp => emp.Salary);
                            break;
                    }
                    break;
            }
            return View(employees);
        }

        public ActionResult Details(int empNo)
        {
            Employee employee = dbContext.Employees
                .Where(emp => emp.EmpNo == empNo).FirstOrDefault();
            return View(empNo);
        }

        public ActionResult Add()
        {
            ViewBag.Policies = dbContext.Policies.ToList();
            return View();
        }

        [HttpPost]
        public ActionResult Add(Employee employee)
        {
            ViewBag.Policies = dbContext.Policies.ToList();
            if (ModelState.IsValid)
            {
                dbContext.Employees.Add(employee);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
                return View("Add");
        }

        public ActionResult Update(int empNo)
        {
            Employee employee = dbContext.Employees.Where(emp => emp.EmpNo == empNo)
                .FirstOrDefault();
            return View(employee);
        }

        [HttpPost]
        public ActionResult Update(int empNo, Employee employee)
        {
            if (ModelState.IsValid)
            {
                Employee employeeUpdated = dbContext.Employees.Where(emp => emp.EmpNo == employee.EmpNo)
                .FirstOrDefault();
                employeeUpdated.Designation = employee.Designation;
                employeeUpdated.Salary = employee.Salary;
                employeeUpdated.FirstName = employee.FirstName;
                employeeUpdated.LastName = employee.LastName;
                employeeUpdated.Username = employee.Username;
                employeeUpdated.Password = employee.Password;
                employeeUpdated.Address = employee.Address;
                employeeUpdated.ContactNo = employee.ContactNo;
                employeeUpdated.State = employee.State;
                employeeUpdated.Country = employee.Country;
                employeeUpdated.City = employee.City;
                employeeUpdated.PolicyId = employee.PolicyId;
                employeeUpdated.PolicyStatus = employee.PolicyStatus;
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            } else
                return RedirectToAction("Update", new {empNo = employee.EmpNo});
        }

        public ActionResult Delete(int empNo)
        {
            Employee employee = dbContext.Employees.Where(emp => emp.EmpNo == empNo)
                .FirstOrDefault();
            return View(employee);
        }

        [HttpPost]
        public ActionResult Delete(int empNo, Employee employee)
        {
            Employee employeeDeleted = dbContext.Employees.Where(emp => emp.EmpNo == empNo)
                .FirstOrDefault();
            dbContext.Employees.Remove(employeeDeleted);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}