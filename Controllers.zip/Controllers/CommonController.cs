﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HealthInsuranceManagementSystem.Controllers
{
    public class CommonController : Controller
    {
        public ActionResult GoBack(string returnUrl)
        {
            return Redirect(returnUrl);
        }
    }
}