﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace HealthInsuranceManagementSystem.Models
{
    public class InsuranceCompany
    {
        [Key]
        public int CompanyId { get; set; }

        [Required(ErrorMessage = "Company Name must not be blank!")]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Address must not be blank!")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Phone number must not be blank!")]
        [RegularExpression(@"^(\+|0)[0-9]+$", ErrorMessage = "Invalid phone number")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Company Website must not be blank!")]
        [Url(ErrorMessage = "Company Website URL is not valid, must start with http:// or https://")]
        public string CompanyWebsite { get; set; }
    }
}