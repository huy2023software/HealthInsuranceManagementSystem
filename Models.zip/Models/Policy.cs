﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlTypes;

namespace HealthInsuranceManagementSystem.Models
{
    public class Policy
    {
        [Key]
        public int PolicyId { get; set; }
        
        [Required(ErrorMessage = "Policy Name can't be blank")]
        public string PolicyName { get; set; }

        [Required(ErrorMessage = "Description can't be blank")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Amount can't be blank")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal Amount{ get; set; }

        [Required(ErrorMessage = "EMI can't be blank")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal EMI { get; set; }

        [Required(ErrorMessage = "Company Id can't be blank")]
        public int CompanyId { get; set; }

        [Required(ErrorMessage = "Medical Id can't be blank")]
        public string MedicalId { get; set; }

        public virtual InsuranceCompany InsuranceCompany { get; set; }
    }
}